---
layout: page
title: About
permalink: /about/
---

I'm Programmer for Python & Django. I've made quite a few web apps, especially on Django. Now, I am doing more on backend.

email: agus[at]python.web.id
